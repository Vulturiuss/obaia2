# Spécification Shopify Dawn inspirée de sonaad.com

_Contexte : fr-FR • Date : 2026-04-10 (Europe/Paris) • Base technique : thème Dawn (Shopify Online Store 2.0)_

## Résumé exécutif

Cette spécification décrit comment reconstruire, à partir du thème Dawn, une boutique avec une **UI/UX très proche** de celle observée sur sonaad.com, tout en remplaçant **tous** les éléments de marque (textes, logo, photos/vidéos, couleurs exactes, wording) par ceux de ta marque. La référence présente une expérience “luxe minimaliste” : beaucoup d’espace blanc, typographie éditoriale, carrousels sobres, tiroirs (menu/panier), et un parcours fortement orienté “waitlist / accès prioritaire”. citeturn28view0turn2view1turn3view0turn10view0

Le document fournit : un audit UI/UX page par page (home, collections, produit, contact, page éditoriale), une cartographie exacte vers l’architecture Dawn (templates JSON + sections/snippets/assets), un design system (tokens CSS, échelles), les comportements JS attendus (carrousels, video hero, cart drawer, waitlist form, variant picker), un plan d’implémentation priorisé, des extraits de code, une checklist QA, des notes de déploiement et des prompts prêts à coller pour ton assistant IA. citeturn9search0turn1search8turn0search16

## Brief projet et contraintes

**Objectif fonctionnel.** Reproduire l’architecture UI/UX de la référence : barre d’annonce “accès prioritaire”, header minimal (menu/recherche/compte/panier), hero “collection” avec CTA, carrousel produits (prix promo + prix normal barré), section produit “showcase” sur la home avec sélection de couleur, capture email “communauté”, FAQ accordéon “waitlist”, réassurance (livraison/paiement/contact), pages collection avec filtres/tri, page produit détaillée (galerie, variantes couleur, storytelling, carrousel d’usages, FAQ, bloc marque), page contact, page histoire. citeturn28view0turn2view0turn2view1turn3view0turn10view0

**Contraintes légales / IP.** La référence indique explicitement que ses contenus (textes, images, graphismes, logos, photos) sont protégés et que toute reproduction/adaptation est interdite sans autorisation écrite. Le projet doit donc :  
- re-développer l’UI (structure + composants + styles) **sans copier** leurs assets, textes, ni code,  
- remplacer les contenus par tes textes/médias,  
- éviter tout wording identique “à la ligne près” sur les pages sensibles (storytelling, arguments marketing). citeturn10view2turn20view0

**Contraintes typographiques.** Les polices demandées :  
- Titres : GFS Didot (Google Fonts), citeturn26search1  
- Texte : Montserrat (Google Fonts). citeturn27search0  
Montserrat mentionne explicitement être sous licence SIL Open Font License ; veille à conserver le respect OFL (ne pas vendre la fonte seule, conserver notices si redistribution). citeturn27search0turn27search2

**Hypothèses (à confirmer par toi).**  
- Tu disposes de tes assets (logo, packshots, photos lifestyle, une vidéo hero si souhaitée, palette de marque exacte).  
- Le mécanisme “waitlist + avantages” est côté UX (capture email + segmentation) ; l’accès anticipé réel nécessite une mécanique marketing (Shopify Forms / email marketing / automation). citeturn21search0turn21search16  
- Version exacte de Dawn non fournie : la spec vise la compatibilité OS 2.0 et un style “Dawn-like” (HTML-first / JS minimal). citeturn0search16

**Checklist assets à fournir (bloquant si absent).**  
Logo (SVG), couleurs de marque (hex), packshots (min 2000px côté long), 3–8 visuels lifestyle, vidéo hero (MP4/Web-friendly) + poster, icônes (SVG) si tu veux un set sur-mesure, textes (home, histoire, FAQ, réassurance), politiques (CGV/retours). citeturn10view2turn28view0

## Audit UI/UX du site cible

**Patterns globaux.**  
- Barre d’annonce “Accès prioritaire — Inscrivez-vous avant l’ouverture des commandes”. citeturn28view0  
- Header : logo/nom, menu, recherche, connexion/compte, panier avec compteur (“0 article”), liens sociaux (Instagram/Pinterest/TikTok). citeturn28view0turn3view0  
- Tiroir panier (drawer) : “Votre panier est vide” + CTA “Explorer nos produits”. citeturn28view0  
- Footer : bloc “À propos de nous”, menu répétitif, bloc “Politiques”. citeturn28view1turn10view2

**Home.** La home enchaîne : hero (média + titre “AURA COLLECTION” + CTA “DÉCOUVRIR”), carrousel produits (4 items/couleurs) affichant prix promo et prix normal, texte de positionnement + CTA, 2 CTAs vers collections, “product showcase” avec galerie multi-images + prix + sélecteur couleur, capture email, FAQ waitlist, réassurance livraison/paiement/contact. citeturn28view0turn28view1

**Collections.** Pages collection : grille produits + “Filtrer et trier”, tri (vedette, meilleures ventes, alpha, prix, date), “En stock uniquement”, filtre prix min/max. citeturn2view0turn23search3

**Produit.** Page produit observée : galerie média, prix promo/prix normal, sélection “Couleur”, bloc “Accès Waitlist” + CTA “ÊTRE INFORMÉ(E) EN PRIORITÉ”, description + liste de détails, partage social, sections storytelling image/texte, mini-blocs bénéfices, carrousel “façons de porter”, FAQ waitlist, bloc marque “AU-DELÀ …” + CTA vers histoire. citeturn2view1turn4view0turn4view2turn16view0turn10view0

**Contact & éditorial.**  
- Contact : formulaire Nom/Email/Message, texte intro. citeturn3view0  
- Histoire : page éditoriale longue, signature fondatrice + image. citeturn10view0  

## Mapping Dawn et arborescence

Le thème Dawn (référence officielle) est conçu “HTML-first, JS seulement si nécessaire” et sert de base saine pour une UX performante. citeturn0search16  
L’architecture OS 2.0 repose sur templates JSON + sections (avec presets pour être ajoutables via l’éditeur). citeturn9search0turn1search8

**Décision d’architecture.** Minimiser la modification des fichiers Dawn “core”, en ajoutant une couche `ob-*` (sections/snippets/assets) et seulement quelques edits ciblés (ex : `layout/theme.liquid` pour charger CSS/JS). citeturn0search10turn1search8

## Design system et interactions

**Images & responsive.** Shopify recommande `image_url` + `image_tag`, qui génère `srcset` par défaut ; le lazy-loading améliore la performance sous la ligne de flottaison. citeturn0search0turn0search2turn0search6turn0search14

**Vidéo.** Le filtre `video_tag` gère plusieurs sources ; Shopify peut générer HLS + fallback MP4. citeturn1search9

**Variants.** Le sélecteur de variantes doit mettre à jour l’affichage (prix, médias, disponibilité, CTA). citeturn22search18turn22search1

**Email capture / waitlist.** Shopify documente le formulaire newsletter via `{% form 'customer' %}` avec `contact[email]`; Shopify Forms peut ajouter tags et segmentation. citeturn21search0turn21search16

**Cart drawer.** Dawn fournit un `cart-drawer` (snippet) qu’on peut styliser/étendre plutôt que réécrire. citeturn0search3

## Plan d’implémentation, QA et déploiement

Le plan suit un ordre “fondations → global → home → produit → collections → pages → polish”. Les extraits de code et instructions détaillées se trouvent dans la version “Claude-ready” ci-dessous (sans citations).

Checklist QA : accessibilité (clavier/focus/aria), performances (LCP/CLS, lazy-load), mobile (breakpoints 750/990 typiques Dawn), cross-browser, conformité RGPD (formulaires), et validation des templates/sections JSON. citeturn0search2turn0search6turn9search0turn1search8

## Claude-ready

```markdown
# Spécification Shopify Dawn inspirée de sonaad.com

Contexte : fr-FR • Date : 2026-04-10 (Europe/Paris) • Base : thème Dawn (Shopify Online Store 2.0)

Objectif : reconstruire une UI/UX très proche de sonaad.com, en remplaçant 100% des éléments de marque (logo, contenus, photos/vidéos, wording, couleurs exactes) par ceux de ta marque. Ne copie aucun asset, aucun texte, aucun code du site source.

## Résumé exécutif

Cette spécification décrit :
- l’audit UI/UX (home, collection, produit, contact, éditorial),
- la cartographie vers Dawn (templates JSON + sections/snippets/assets),
- un design system (tokens CSS, composants UI),
- les comportements JS attendus (carrousels, hero vidéo, drawer panier, waitlist form, variant updates),
- un plan d’implémentation priorisé, avec extraits Liquid/CSS/JS,
- une checklist QA et des notes de déploiement,
- des prompts prêts à coller pour exécuter le travail avec un assistant IA ayant accès au dossier du thème.

## Brief projet et contraintes

### Contraintes légales / IP

- Interdiction de copier : images, vidéos, logo, textes, ingrédients marketing, code, structure HTML exacte si elle est trop distinctive.
- Autorisé : reproduire une expérience comparable (layout, composants, parcours), en implémentant ton propre code et ton propre branding.

### Périmètre fonctionnel

À reproduire (structure & comportements) :
- Barre d’annonce “accès prioritaire” (message paramétrable).
- Header minimal : logo centré, menu, recherche, compte, panier (drawer), liens sociaux.
- Home : hero “collection” avec CTA ; carrousel produits ; CTAs vers catégories ; “product showcase” avec galerie + prix + sélection couleur ; capture email ; FAQ accordéon ; réassurance.
- Collection : product grid + filtres/tri (facets), filtre prix, “en stock uniquement”.
- Produit : galerie média, prix promo/prix normal, variantes couleur (swatches), CTA waitlist + (option) add-to-cart, description + détails, storytelling, carrousel “façons de porter”, FAQ, bloc marque “au-delà…”.
- Contact : page + formulaire.
- Éditorial : page “histoire” avec texte long + image.

### Typographies imposées

- Titres : GFS Didot
- Texte & UI : Montserrat

### Hypothèses et dépendances (à valider)

Tu dois fournir :
- Logo (SVG recommandé).
- Couleurs de marque exactes (hex).
- Packshots produits (fond blanc) et photos lifestyle (fond neutre).
- (Option) vidéo hero MP4 + image poster.
- Textes (home, FAQ, histoire, réassurance).

Waitlist : UX (collecte email) + segmentation marketing. Le “vrai” accès anticipé nécessite automatisation (ex : Shopify Forms + email marketing).

## Audit UI/UX du site cible

### Patterns globaux

- Announcement bar / barre d’annonce : message d’accès prioritaire.
- Drawer menu + drawer panier.
- Header : logo/nom, menu, recherche, compte, panier, social.
- Footer : “à propos” + menus + liens politiques.

### Page d’accueil

Ordre cible :
1) Hero média (image/vidéo) + titre en capitales + CTA.
2) Carrousel produits (collection) : cartes produit avec prix promo + prix normal barré + flèches.
3) Texte manifeste + CTA vers page histoire.
4) 2 tuiles CTA vers catégories (collection / accessoires).
5) Product showcase : mini fiche produit (galerie multi-images + prix + sélecteur couleur).
6) Email capture “communauté” (champ email + bouton).
7) FAQ accordéon “comment fonctionne la waitlist ?”.
8) Réassurance : livraison offerte (seuil), contact, paiement sécurisé.
9) Footer.

### Pages collection

- Titre de collection.
- Product grid (2–4 colonnes selon breakpoint).
- “Filtrer et trier” : tri + stock + prix min/max.

### Page produit

Structure cible :
1) Galerie média (images + éventuellement vidéo) + thumbnails.
2) Zone achat : Titre, prix promo/prix normal, sélecteur couleur (swatches), CTA waitlist (et/ou add-to-cart selon dispo).
3) Description (texte) + Détails (liste).
4) Partage social.
5) Storytelling (sections image + texte).
6) Bénéfices en 3 items (icône+titre+texte court).
7) Carrousel “façons de porter” (4 slides).
8) FAQ waitlist (accordéon).
9) Bloc marque “au-delà…” avec image + CTA vers page histoire.

### Contact

- Intro + formulaire (nom/email/message).

### Page éditoriale

- Long form texte + image + signature.

## Mapping Dawn et arborescence

Principe : créer une couche `ob-*` + overrides CSS, et minimiser la modification des fichiers core.

### Tableau de mapping fichiers

| Chemin | Action | Rôle | Notes |
|---|---:|---|---|
| layout/theme.liquid | Modifier | Charger fonts + CSS/JS ob-* | Modification minimale, indispensable |
| assets/ob-settings.css | Créer | Tokens : typo, couleurs, spacing | Variables CSS |
| assets/ob-components.css | Créer | Boutons, forms, cards, icons | UI kit |
| assets/ob-sections.css | Créer | Styles des sections ob-* | |
| assets/ob-interactions.js | Créer | Interactions légères (optionnel) | Respect “JS minimal” |
| sections/ob-hero-media.liquid | Créer | Hero image/vidéo + CTA | Remplace besoin de slideshow si voulu |
| sections/ob-featured-carousel.liquid | Créer | Carrousel produits | Peut réutiliser slider Dawn |
| sections/ob-collection-cta-tiles.liquid | Créer | 2 tuiles CTA | |
| sections/ob-product-showcase.liquid | Créer | Produit vedette sur home | Variante + mini galerie |
| sections/ob-email-waitlist.liquid | Créer | Capture email | Form ‘customer’ |
| sections/ob-faq-accordion.liquid | Créer | FAQ accordéon | Accessible |
| sections/ob-trust-row.liquid | Créer | Réassurance | 3 items |
| sections/ob-product-story-split.liquid | Créer | Image + texte | Répétable sur product |
| sections/ob-product-usage-carousel.liquid | Créer | Carrousel 4 usages | |
| sections/ob-brand-callout.liquid | Créer | Bloc marque + CTA | |
| snippets/ob-button.liquid | Créer | Boutons (primary/secondary/link) | Réutilisable |
| snippets/ob-icon-set.liquid | Créer | Icônes SVG | Inline |
| templates/index.json | Créer/Modifier | Assemblage home | |
| templates/product.json | Créer/Modifier | Assemblage product | |
| templates/collection.json | Modifier léger | Garder facets + style | Utiliser Dawn facets |
| templates/page.contact.json | Modifier léger | Contact template | |
| templates/page.notre-histoire.json | Créer | Page histoire | |

### Composition templates (recommandée)

- index.json : announcement-bar + header + ob-hero-media + ob-featured-carousel + rich-text manifeste + ob-collection-cta-tiles + ob-product-showcase + ob-email-waitlist + ob-faq-accordion + ob-trust-row + footer
- product.json : main-product (Dawn) + ob-product-story-split xN + ob-product-usage-carousel + ob-faq-accordion + ob-brand-callout
- collection.json : main-collection-product-grid (Dawn) + style override
- page.contact.json : main-page + contact-form (Dawn)
- page.notre-histoire.json : main-page + image-with-text (ou custom section)

## Design system et interactions

### Tokens CSS

Créer `assets/ob-settings.css` et définir :

~~~css
:root {
  /* Typo */
  --ob-font-heading: "GFS Didot", serif;
  --ob-font-body: "Montserrat", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;

  /* Tailles (fluid simple) */
  --ob-text-xs: 12px;
  --ob-text-sm: 14px;
  --ob-text-md: 16px;
  --ob-text-lg: 18px;

  --ob-h1: clamp(34px, 4vw, 52px);
  --ob-h2: clamp(26px, 3vw, 40px);
  --ob-h3: clamp(20px, 2vw, 28px);

  /* Couleurs (approximations, à remplacer par ta palette exacte) */
  --ob-white: #fafafa;
  --ob-offwhite: #f6f8f7;
  --ob-taupe-100: #cabaab;
  --ob-taupe-200: #b19f8d;
  --ob-moka-500: #866951;
  --ob-ink: #1d1e1f;
  --ob-grey-500: #88888a;

  /* Spacing scale */
  --ob-space-1: 4px;
  --ob-space-2: 8px;
  --ob-space-3: 12px;
  --ob-space-4: 16px;
  --ob-space-5: 24px;
  --ob-space-6: 32px;
  --ob-space-7: 48px;
  --ob-space-8: 64px;

  /* Radius */
  --ob-radius-sm: 6px;
  --ob-radius-md: 12px;

  /* Layout */
  --ob-page-max: 1200px;
  --ob-gutter: 20px;

  /* Buttons */
  --ob-btn-height: 44px;
  --ob-btn-radius: 999px;

  /* Motion */
  --ob-ease: cubic-bezier(.2,.8,.2,1);
  --ob-duration: 220ms;
}
~~~

### Styles globaux

Dans `assets/ob-components.css` :

- Appliquer typographies :
  - h1-h6 => heading font, weight normal, tracking léger, option uppercase sur sections “eyebrow”.
  - body, input, button, nav => body font.

- Boutons :
  - Primary : fond ink, texte offwhite, pill radius, hover léger.
  - Secondary : fond transparent, border ink.
  - Link : underline subtil.

- Forms :
  - Inputs : fond transparent, border 1px taupe, focus ring.
  - Email capture : input + bouton alignés (desktop) et stack (mobile).

### Guideline images

- Toujours utiliser `image_url` + `image_tag`.
- Above-the-fold : éviter lazy-loading, utiliser fetchpriority si possible.
- Below-the-fold : loading="lazy".
- Définir widths/sizes pour srcset automatique.

Exemple snippet :

~~~liquid
{% assign sizes = '(min-width: 990px) 600px, 90vw' %}
{{ section.settings.image
  | image_url: width: 1600
  | image_tag:
    widths: '360, 540, 720, 960, 1200, 1600',
    sizes: sizes,
    loading: 'lazy',
    alt: section.settings.image.alt | escape
}}
~~~

### Iconographie

- Utiliser SVG inline (snippets/ob-icon-set.liquid) pour :
  - livraison, paiement, contact, play (vidéo), flèches carrousel, plus/minus (accordion).

### Interactions JS à implémenter

Objectif : JS minimal, réutiliser Dawn (slider, variant picker, cart drawer) autant que possible.

- Hero vidéo :
  - Autoplay muted loop.
  - Si prefers-reduced-motion: réduire (pas d’autoplay) et afficher poster + bouton play.
  - Fallback image si vidéo absente.

- Carrousels :
  - Utiliser slider Dawn si possible (markup compatible).
  - Boutons prev/next, dots/counter optionnel.

- Cart drawer :
  - Conserver Dawn drawer (AJAX add-to-cart).
  - Ajouter “Continue shopping” + mini trust (option) via CSS.

- Waitlist form :
  - UX : champ email + CTA ; affichage success/error.
  - Option : tag “waitlist” (si Shopify Forms) ; sinon stocker comme newsletter.

- Variant picker :
  - Sur changement : update prix, média, bouton (add-to-cart vs waitlist), label couleur sélectionnée.

## Spécification sections ob-*

Pour chaque section : but, settings schema, blocks, presets, accessibilité.

### Section ob-hero-media

But : hero média (image/vidéo) + overlay léger + titre + CTA.

Settings (schema) :

| id | type | défaut | note |
|---|---|---:|---|
| media_type | select | video | video / image |
| video | video | — | vidéo Shopify host |
| video_url | video_url | — | fallback YouTube/Vimeo |
| poster | image_picker | — | poster |
| image_desktop | image_picker | — | |
| image_mobile | image_picker | — | |
| heading | inline_richtext | COLLECTION | capitals recommandé |
| subheading | richtext | — | option |
| button_label | text | Découvrir | |
| button_link | url | — | |
| overlay_opacity | range 0–80 | 10 | |
| min_height | select | large | |

Blocks : optionnels (ex : aucun, ou “badge”).
Presets : 1 preset “Hero média”.

Accessibilité :
- Si vidéo : bouton play accessible + aria-label.
- Texte contrasté vs overlay.

Code section (à créer : sections/ob-hero-media.liquid) :

~~~liquid
{% comment %} sections/ob-hero-media.liquid {% endcomment %}
<section class="ob-hero ob-hero--{{ section.settings.min_height }}" style="--ob-overlay: {{ section.settings.overlay_opacity | divided_by: 100.0 }};">
  <div class="ob-hero__media">
    {% if section.settings.media_type == 'video' and section.settings.video != blank %}
      {{ section.settings.video | video_tag: autoplay: true, loop: true, muted: true, controls: false, playsinline: true, class: 'ob-hero__video' }}
    {% elsif section.settings.media_type == 'video' and section.settings.video_url != blank %}
      <div class="ob-hero__embed">
        {% comment %} Utiliser un deferred embed si nécessaire {% endcomment %}
        <iframe
          src="https://www.youtube.com/embed/{{ section.settings.video_url.id }}?autoplay=1&mute=1&loop=1&playlist={{ section.settings.video_url.id }}"
          title="{{ section.settings.heading | escape }}"
          allow="autoplay; encrypted-media"
          allowfullscreen></iframe>
      </div>
    {% else %}
      {% assign img = section.settings.image_desktop %}
      {% if img != blank %}
        {{ img | image_url: width: 2400 | image_tag: widths: '750, 1100, 1500, 2000, 2400', sizes: '100vw', class: 'ob-hero__img', alt: img.alt | escape }}
      {% endif %}
    {% endif %}
    <div class="ob-hero__overlay" aria-hidden="true"></div>
  </div>

  <div class="ob-hero__content page-width">
    {% if section.settings.heading != blank %}
      <h1 class="ob-hero__heading">{{ section.settings.heading }}</h1>
    {% endif %}
    {% if section.settings.button_label != blank and section.settings.button_link != blank %}
      <a class="ob-btn ob-btn--primary" href="{{ section.settings.button_link }}">{{ section.settings.button_label | escape }}</a>
    {% endif %}
  </div>
</section>

{% schema %}
{
  "name": "OB Hero Média",
  "tag": "section",
  "class": "section",
  "settings": [
    { "type": "select", "id": "media_type", "label": "Type de média", "default": "video", "options": [
      { "value": "video", "label": "Vidéo" },
      { "value": "image", "label": "Image" }
    ]},
    { "type": "video", "id": "video", "label": "Vidéo (Shopify-hosted)" },
    { "type": "video_url", "id": "video_url", "label": "Vidéo (YouTube/Vimeo)", "accept": ["youtube","vimeo"] },
    { "type": "image_picker", "id": "poster", "label": "Poster (fallback)" },
    { "type": "image_picker", "id": "image_desktop", "label": "Image desktop" },
    { "type": "image_picker", "id": "image_mobile", "label": "Image mobile" },
    { "type": "inline_richtext", "id": "heading", "label": "Titre", "default": "AURA COLLECTION" },
    { "type": "text", "id": "button_label", "label": "Label bouton", "default": "DÉCOUVRIR" },
    { "type": "url", "id": "button_link", "label": "Lien bouton" },
    { "type": "range", "id": "overlay_opacity", "label": "Opacité overlay", "min": 0, "max": 80, "step": 5, "unit": "%", "default": 10 },
    { "type": "select", "id": "min_height", "label": "Hauteur", "default": "large", "options": [
      { "value": "medium", "label": "Moyenne" },
      { "value": "large", "label": "Grande" },
      { "value": "full", "label": "Plein écran" }
    ]}
  ],
  "presets": [
    { "name": "OB Hero Média" }
  ]
}
{% endschema %}
~~~

CSS (à ajouter dans assets/ob-sections.css) :

~~~css
.ob-hero { position: relative; background: var(--ob-offwhite); }
.ob-hero__media { position: relative; overflow: hidden; }
.ob-hero__video, .ob-hero__img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ob-hero--medium .ob-hero__media { height: 60vh; min-height: 520px; }
.ob-hero--large .ob-hero__media { height: 75vh; min-height: 620px; }
.ob-hero--full .ob-hero__media { height: 100vh; }
.ob-hero__overlay { position: absolute; inset: 0; background: rgba(0,0,0,var(--ob-overlay)); }
.ob-hero__content { position: absolute; inset: 0; display: grid; place-content: center; gap: var(--ob-space-5); text-align: center; padding: var(--ob-space-8) var(--ob-gutter); }
.ob-hero__heading { font-family: var(--ob-font-heading); font-size: var(--ob-h1); color: var(--ob-white); letter-spacing: .06em; text-transform: uppercase; margin: 0; }
~~~

JS (optionnel : assets/ob-interactions.js) :

~~~js
// Respect prefers-reduced-motion : désactiver autoplay si nécessaire
(() => {
  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduced) return;
  document.querySelectorAll('.ob-hero__video').forEach(v => {
    v.pause();
    v.removeAttribute('autoplay');
    v.controls = true;
  });
})();
~~~

### Section ob-featured-carousel

But : carrousel produits (collection) avec cartes produit, prix promo + prix normal barré, boutons prev/next, mobile scroll.

Settings :

| id | type | défaut |
|---|---|---:|
| heading | inline_richtext | Collection |
| collection | collection | — |
| limit | range 4–12 | 4 |
| show_compare_at | checkbox | true |
| enable_desktop_slider | checkbox | true |
| enable_mobile_slider | checkbox | true |

Blocks : aucun (liste auto depuis collection).
Presets : 1 preset.

Accessibilité :
- Boutons prev/next avec aria-label.
- Navigation clavier si slider.

Implémentation recommandée :
- Copier/adapter featured-collection (Dawn) dans `sections/ob-featured-carousel.liquid` pour garder slider compatible.

### Section ob-product-showcase

But : mini fiche produit sur home (galerie + prix + sélection couleur + CTA).

Settings :

| id | type | défaut |
|---|---|---:|
| product | product | — |
| heading | inline_richtext | Nom produit |
| show_gallery | checkbox | true |
| variant_option_name | text | Couleur |
| cta_mode | select | waitlist |
| cta_label | text | ÊTRE INFORMÉ(E) |
| cta_link | url | — |

Blocks : optionnels (ex : “bullet benefits”).
Presets : 1 preset.

Accessibilité :
- Le picker couleur doit être un vrai champ (radio) avec labels.

### Section ob-email-waitlist

But : capture email (newsletter / waitlist).

Settings :

| id | type | défaut |
|---|---|---:|
| heading | inline_richtext | REJOIGNEZ LA COMMUNAUTÉ... |
| placeholder | text | E-mail |
| button_label | text | REJOINDRE |
| success_message | text | Merci ! |

Blocks : aucun.
Presets : 1 preset.

Accessibilité :
- label associe input
- messages success/error annoncés.

Code (sections/ob-email-waitlist.liquid) :

~~~liquid
<section class="ob-waitlist page-width">
  <h2 class="ob-eyebrow">{{ section.settings.heading }}</h2>

  {% form 'customer', class: 'ob-form' %}
    <input type="hidden" name="contact[accepts_marketing]" value="true">
    <div class="ob-form__row">
      <label class="visually-hidden" for="ObWaitlistEmail-{{ section.id }}">Email</label>
      <input
        id="ObWaitlistEmail-{{ section.id }}"
        type="email"
        name="contact[email]"
        required
        placeholder="{{ section.settings.placeholder | escape }}"
        class="ob-input"
        autocomplete="email">
      <button class="ob-btn ob-btn--primary" type="submit">{{ section.settings.button_label | escape }}</button>
    </div>

    {% if form.posted_successfully? %}
      <p class="ob-form__success" role="status">{{ section.settings.success_message | escape }}</p>
    {% endif %}
    {% if form.errors %}
      <p class="ob-form__error" role="alert">{{ form.errors | default_errors }}</p>
    {% endif %}
  {% endform %}
</section>

{% schema %}
{
  "name": "OB Email Waitlist",
  "tag": "section",
  "class": "section",
  "settings": [
    { "type": "inline_richtext", "id": "heading", "label": "Titre", "default": "REJOIGNEZ LA COMMUNAUTÉ ET DÉCOUVREZ LES DERNIÈRES ACTUALITÉS" },
    { "type": "text", "id": "placeholder", "label": "Placeholder", "default": "E-mail" },
    { "type": "text", "id": "button_label", "label": "Bouton", "default": "REJOINDRE" },
    { "type": "text", "id": "success_message", "label": "Message succès", "default": "Merci, vous êtes inscrit(e)." }
  ],
  "presets": [
    { "name": "OB Email Waitlist" }
  ]
}
{% endschema %}
~~~

CSS (assets/ob-components.css) :

~~~css
.ob-eyebrow { font-family: var(--ob-font-body); font-size: var(--ob-text-sm); letter-spacing: .08em; text-transform: uppercase; color: var(--ob-ink); margin: 0 0 var(--ob-space-4); }
.ob-form__row { display: grid; grid-template-columns: 1fr auto; gap: var(--ob-space-3); align-items: center; }
.ob-input { height: var(--ob-btn-height); border: 1px solid var(--ob-taupe-200); border-radius: var(--ob-btn-radius); padding: 0 var(--ob-space-4); background: transparent; font-family: var(--ob-font-body); }
.ob-input:focus { outline: 2px solid var(--ob-ink); outline-offset: 2px; }
.ob-btn { height: var(--ob-btn-height); border-radius: var(--ob-btn-radius); padding: 0 var(--ob-space-5); font-family: var(--ob-font-body); letter-spacing: .08em; text-transform: uppercase; }
.ob-btn--primary { background: var(--ob-ink); color: var(--ob-offwhite); border: 1px solid var(--ob-ink); }
.ob-btn--primary:hover { opacity: .92; }
@media (max-width: 749px) {
  .ob-form__row { grid-template-columns: 1fr; }
}
~~~

### Section ob-faq-accordion

But : accordéon FAQ.

Settings :
- heading (inline_richtext)

Blocks (répétables) :
- question (text)
- answer (richtext)

Presets : 1 preset avec 4 blocs.

Accessibilité :
- Bouton <button> avec aria-expanded et aria-controls
- Panneau role region optionnel

Code (sections/ob-faq-accordion.liquid) :

~~~liquid
<section class="ob-faq page-width">
  <h2 class="ob-faq__title">{{ section.settings.heading }}</h2>

  <div class="ob-accordion" data-ob-accordion>
    {% for block in section.blocks %}
      <div class="ob-acc-item" {{ block.shopify_attributes }}>
        <button class="ob-acc-trigger" type="button" aria-expanded="false" aria-controls="ObAccPanel-{{ section.id }}-{{ forloop.index }}">
          <span>{{ block.settings.question | escape }}</span>
          <span class="ob-acc-icon" aria-hidden="true">+</span>
        </button>
        <div id="ObAccPanel-{{ section.id }}-{{ forloop.index }}" class="ob-acc-panel" hidden>
          <div class="ob-acc-panel__inner">{{ block.settings.answer }}</div>
        </div>
      </div>
    {% endfor %}
  </div>
</section>

{% schema %}
{
  "name": "OB FAQ Accordion",
  "tag": "section",
  "class": "section",
  "settings": [
    { "type": "inline_richtext", "id": "heading", "label": "Titre", "default": "COMMENT FONCTIONNE LA WAITLIST ?" }
  ],
  "blocks": [
    {
      "type": "item",
      "name": "Question/Réponse",
      "settings": [
        { "type": "text", "id": "question", "label": "Question", "default": "QU'EST-CE QU'UNE WAITLIST ?" },
        { "type": "richtext", "id": "answer", "label": "Réponse", "default": "<p>Explique ici ta mécanique.</p>" }
      ]
    }
  ],
  "presets": [
    {
      "name": "OB FAQ Accordion",
      "blocks": [
        { "type": "item" },
        { "type": "item" },
        { "type": "item" },
        { "type": "item" }
      ]
    }
  ]
}
{% endschema %}
~~~

JS (assets/ob-interactions.js) :

~~~js
(() => {
  document.querySelectorAll('[data-ob-accordion]').forEach(acc => {
    acc.addEventListener('click', (e) => {
      const btn = e.target.closest('.ob-acc-trigger');
      if (!btn) return;
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      const panelId = btn.getAttribute('aria-controls');
      const panel = panelId ? document.getElementById(panelId) : null;

      btn.setAttribute('aria-expanded', String(!expanded));
      if (panel) panel.hidden = expanded;

      // Option "one open at a time" : fermer les autres
      acc.querySelectorAll('.ob-acc-trigger').forEach(other => {
        if (other === btn) return;
        other.setAttribute('aria-expanded', 'false');
        const otherPanel = document.getElementById(other.getAttribute('aria-controls'));
        if (otherPanel) otherPanel.hidden = true;
      });
    });
  });
})();
~~~

CSS (assets/ob-sections.css) :

~~~css
.ob-faq__title { font-family: var(--ob-font-body); letter-spacing: .08em; text-transform: uppercase; font-size: var(--ob-text-sm); margin: 0 0 var(--ob-space-4); }
.ob-acc-trigger { width: 100%; display: flex; justify-content: space-between; gap: var(--ob-space-3); border: 0; background: transparent; padding: var(--ob-space-4) 0; border-bottom: 1px solid var(--ob-taupe-200); font-family: var(--ob-font-body); text-align: left; }
.ob-acc-panel__inner { padding: var(--ob-space-4) 0; color: var(--ob-ink); }
~~~

### Section ob-trust-row

But : réassurance 3 items.

Settings :
- heading (optionnel)
Blocks :
- icon (select), title (text), text (text)

Presets :
- 3 items par défaut.

Accessibilité :
- SVG décorative => aria-hidden, sinon title/desc.

### Cart drawer (Dawn) : style + micro-extensions

But : garder cart-drawer Dawn, mais styliser.
Action :
- Modifier CSS (ob-components.css) pour harmoniser typo, boutons, spacing.
- Option : ajouter une ligne “Continue shopping” si non présente.

## Implémentation étape par étape

### Timeline

| Phase | Priorité | Objectif | Livrables |
|---|---:|---|---|
| Fondations | P0 | Fonts + tokens + CSS load | theme.liquid + ob-*.css |
| Global | P0 | Header / drawer / footer style | CSS overrides |
| Home | P0 | sections home + index.json | ob-hero-media, ob-featured-carousel, ob-product-showcase, ob-email-waitlist, ob-faq, ob-trust |
| Produit | P0 | product.json + sections storytelling + usage carousel | ob-product-story-split, ob-product-usage-carousel, ob-brand-callout |
| Collections | P1 | collection.json + style facets | CSS |
| Pages | P1 | contact + histoire | templates + sections |
| QA/Perf | P0 | tests + corrections | checklist complétée |

### Instructions d’édition exactes

1) layout/theme.liquid
- Ajouter Google Fonts <link> dans <head>.
- Charger les CSS ob-* après base.css.
- Charger ob-interactions.js avec defer.

Exemple :

~~~liquid
{{ 'ob-settings.css' | asset_url | stylesheet_tag }}
{{ 'ob-components.css' | asset_url | stylesheet_tag }}
{{ 'ob-sections.css' | asset_url | stylesheet_tag }}
<script src="{{ 'ob-interactions.js' | asset_url }}" defer></script>
~~~

2) Créer assets/ob-settings.css, ob-components.css, ob-sections.css, ob-interactions.js
3) Créer sections ob-* (ci-dessus)
4) Créer/Modifier templates JSON
5) Styliser header/panier/typographies globales

## Prompt prêts à coller

Prompt “setup”
> Lis cette spec. Implémente les nouveaux fichiers ob-* (assets, sections, snippets, templates). Minimiser les modifications du core Dawn. Documente chaque modification.

Prompt “fonts”
> Ajoute les fonts Google (GFS Didot + Montserrat) dans theme.liquid et mappe sur tokens CSS. Applique headings/body partout, y compris boutons et form.

Prompt “home”
> Construis index.json avec les sections ob-* dans l’ordre défini. Crée les sections manquantes et leurs schemas. Ajoute styles CSS correspondants.

Prompt “product”
> Mets en place product.json : main-product + storytelling + usage carousel + FAQ + brand callout. Le variant picker “Couleur” doit mettre à jour prix/media/CTA.

Prompt “collection”
> Ajuste collection.json pour conserver facets/tri. Harmonise styles avec tokens.

Prompt “QA”
> Lance un audit accessibilité (focus, aria, accordéon), perf (lazyload, images widths), responsive (mobile/desktop) et corrige.

```