/* ==========================================================================
   OB Interactions — Minimal JS layer for Obaia theme
   ========================================================================== */

(() => {
  'use strict';

  /* ---- 1. Accordion (FAQ) ---- */
  function initAccordions() {
    document.querySelectorAll('[data-ob-accordion]').forEach((acc) => {
      acc.addEventListener('click', (e) => {
        const btn = e.target.closest('.ob-acc-trigger');
        if (!btn) return;

        const expanded = btn.getAttribute('aria-expanded') === 'true';
        const panelId = btn.getAttribute('aria-controls');
        const panel = panelId ? document.getElementById(panelId) : null;

        // Toggle clicked
        btn.setAttribute('aria-expanded', String(!expanded));
        if (panel) panel.hidden = expanded;

        // Close others (one-at-a-time)
        acc.querySelectorAll('.ob-acc-trigger').forEach((other) => {
          if (other === btn) return;
          other.setAttribute('aria-expanded', 'false');
          const otherPanel = document.getElementById(other.getAttribute('aria-controls'));
          if (otherPanel) otherPanel.hidden = true;
        });
      });
    });
  }

  /* ---- 2. Respect prefers-reduced-motion for hero video ---- */
  function handleReducedMotion() {
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!reduced) return;

    document.querySelectorAll('.ob-hero__video').forEach((v) => {
      v.pause();
      v.removeAttribute('autoplay');
      v.controls = true;
    });
  }

  /* ---- 3. Product showcase — variant picker update ---- */
  function initShowcaseVariantPicker() {
    document.querySelectorAll('[data-ob-showcase]').forEach((showcase) => {
      const radios = showcase.querySelectorAll('input[type="radio"][name^="ob-color"]');
      const priceEl = showcase.querySelector('[data-ob-showcase-price]');
      const comparePriceEl = showcase.querySelector('[data-ob-showcase-compare-price]');
      const gallery = showcase.querySelector('[data-ob-showcase-gallery]');
      const labelEl = showcase.querySelector('[data-ob-showcase-color-label]');

      radios.forEach((radio) => {
        radio.addEventListener('change', () => {
          // Update colour label
          if (labelEl) labelEl.textContent = radio.value;

          // Update price if data attributes present
          if (priceEl && radio.dataset.price) {
            priceEl.textContent = radio.dataset.price;
          }
          if (comparePriceEl && radio.dataset.comparePrice) {
            comparePriceEl.textContent = radio.dataset.comparePrice;
          }

          // Update gallery image if data attribute present
          if (gallery && radio.dataset.image) {
            const mainImg = gallery.querySelector('.ob-showcase__main-img');
            if (mainImg) {
              mainImg.src = radio.dataset.image;
              mainImg.srcset = '';
            }
          }
        });
      });
    });
  }

  /* ---- Init ---- */
  function init() {
    initAccordions();
    handleReducedMotion();
    initShowcaseVariantPicker();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Re-init on Shopify section events (Theme Editor)
  document.addEventListener('shopify:section:load', init);
})();
